package com.example.alpha;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.LinearLayout;
import android.widget.TextView;

public class login extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstancesState){
        super.onCreate(savedInstancesState);
        setContentView(R.layout.login);

        TextView signUpTextLink = findViewById(R.id.signUpTextLink);

        signUpTextLink.setOnClickListener(e ->{
            Intent intent = new Intent(login.this, register.class);
            startActivity(intent);
        });
    }
}
