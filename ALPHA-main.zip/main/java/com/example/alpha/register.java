package com.example.alpha;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class register extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstancesSate){
        super.onCreate(savedInstancesSate);
        setContentView(R.layout.register);

        Button submitRegisterBTN = findViewById(R.id.submitRegisterBTN);
        ImageButton backButton = findViewById(R.id.backButton);

        submitRegisterBTN.setOnClickListener(e ->{
            Intent intent = new Intent(this, login.class);
            startActivity(intent);
        });

        backButton.setOnClickListener(e ->{
            Intent intent = new Intent(register.this, login.class);
            startActivity(intent);
        });

    }
}
